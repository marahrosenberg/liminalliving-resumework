# LiminalLiving.ResumeWork — Full Reference
## Resume & Cover Letter Framework | Public Edition
## A Liminal Living Tool | CC BY-NC 4.0

---

## TABLE OF CONTENTS

1. [Orientation](#orientation)
2. [Step 1 — JD Deconstruction](#step-1-jd-deconstruction)
3. [Step 2 — Experience Mapping](#step-2-experience-mapping)
4. [Step 3 — The Victory Bullet Formula](#step-3-the-victory-bullet-formula)
5. [Step 3A — Ownership Validation](#step-3a-ownership-validation)
6. [Step 4 — Summary & Competencies](#step-4-summary--competencies)
7. [Step 5 — Cover Letter](#step-5-cover-letter)
8. [Step 6 — Employment History & Dates](#step-6-employment-history--dates)
9. [Step 7 — Technical Standards](#step-7-technical-standards)
10. [Step 8 — QA Checklist](#step-8-qa-checklist)
11. [Step 9 — Delivery](#step-9-delivery)
12. [Cross-Domain Positioning](#cross-domain-positioning)
13. [Action Verb Banks](#action-verb-banks)
14. [The Three-Question Test](#the-three-question-test)

---

## ORIENTATION

This is a precision positioning document, not a biography. Every word must answer:
**"Why hire me for THIS role?"**

A non-linear career is not scattered — it is cross-domain depth. The challenge is not
explaining the pivots; it is selecting which thread to pull for each specific role. This
protocol treats the non-linear career as an asset to be framed, not a liability to manage.

---

## STEP 1: JD DECONSTRUCTION

### Tiered Keyword Classification

**Tier 1 (100% Inclusion):**
Job title exact match, required technical tools, methodologies, hard certifications, industry
terms, compliance frameworks. These must appear verbatim in the resume.

**Tier 2 (80% Inclusion):**
Preferred qualifications, soft competencies (stakeholder management, cross-functional
leadership), domain familiarity, adjacent credentials.

**Tier 3 (50% Inclusion):**
Organizational values language, nice-to-have skills, adjacent competencies.

### Identify the Wound

What specific organizational problem does this role exist to solve? What is bleeding that
this hire is meant to stop?

Common wounds by role type:
- **Transformation / change management:** Initiatives that stall, adoption that doesn't
  hold, teams that revert after the consultant leaves
- **Program / project operations:** Execution gaps between strategy and delivery, portfolios
  no one can see clearly, deadlines that slip without warning
- **People / HR / culture:** Turnover that's costing more than it appears, culture drift
  post-merger, managers who can't manage
- **Technical / IT / security:** Fragmented infrastructure, compliance exposure, systems
  that don't talk to each other
- **Nonprofit / social impact:** Programs that don't outlast their founders, execution gaps
  between mission and delivery, grant outcomes that can't be measured

**Output format after JD deconstruction:**
```
KEY REQUIREMENTS (ranked by JD emphasis):
1. [requirement]
2. [requirement]
...

TIERED KEYWORD LIST:
Tier 1: [keywords]
Tier 2: [keywords]
Tier 3: [keywords]

WOUND IDENTIFICATION:
[What is this hire meant to fix?]

SENIORITY INDICATORS:
[Budget scope / team size / org level signals]

GAP ANALYSIS:
Strong alignment: [areas]
Creative positioning needed: [areas]
```

---

## STEP 2: EXPERIENCE MAPPING

### Metric Hardening

For each relevant experience, identify:
- **Before vs. After:** What changed because of this work?
- **Scale:** Users, budget, teams, locations, volume
- **Timeline:** How fast, under what pressure, with what constraints?

### Sequential Questioning

Address one experience gap at a time. Wait for the response before moving to the next.
Never ask more than one question at once — this is where the session becomes a conversation,
not a form.

### Adjacency Rule

Map experience from adjacent domains to current role requirements.

Ask: *"What does this experience prove about how I operate — and does that proof matter here?"*

Examples of adjacency moves:
- Crisis coordination → high-stakes execution under pressure
- Volunteer leadership → mobilizing without authority
- Teaching or training → knowledge transfer at scale
- Caregiving gaps → project management, prioritization under constraint
- Military service → operational precision, team leadership, mission-driven execution
- Entrepreneurship → ownership mentality, resource constraint, end-to-end accountability

---

## STEP 3: THE VICTORY BULLET FORMULA

### Formula

```
[Strong Action Verb] + [Problem/Risk Inherited] + [Solution/Approach] + [Trade-off Navigated] + [Quantified Impact]
```

### ATS Specifications

- **Max 160 characters per bullet** (including spaces) — hard limit
- **Split Strategy:** If an achievement exceeds 160 chars, lead bullet = outcome, follow
  bullet = method. Both must be independently meaningful.

### Examples

**Before (weak):**
> Helped manage a project that improved team performance.

**After (Victory Bullet):**
> Restructured stalled 8-team delivery program; introduced phased milestones that cut
> missed deadlines by 40% in 90 days. *(134 chars)*

**Before (weak):**
> Responsible for onboarding new employees.

**After:**
> Built onboarding program from scratch for 200-person org; 92% 90-day retention vs. 71%
> prior-year baseline. *(108 chars)*

---

## STEP 3A: OWNERSHIP VALIDATION (MANDATORY)

Every bullet must answer: **"What would have failed or gone wrong if I didn't step in?"**

**Pressure Test:**
1. Name the specific problem owned and risk prevented
2. Vary the tension across bullets — rotate through:
   - Speed vs. Stability
   - Autonomy vs. Standardization
   - Scale vs. Quality
   - Compliance vs. Velocity
   - Short-term pressure vs. Long-term sustainability
3. Verify character count. If > 160, split and re-verify metrics in both halves.

---

## STEP 4: SUMMARY & COMPETENCIES

### Professional Summary

3–4 lines. Must include top 5 Tier 1 keywords. Pass the "6-second scan": job title and
years of experience must be immediately visible.

**Non-linear career framing rule:**
The summary does the pivoting work so the bullets don't have to explain themselves.
If applying for a specific track, the summary speaks only from that track's perspective —
other experience appears as supporting evidence of real-world scale, not as separate
identities requiring explanation.

**Template:**
```
[Track-aligned title] with [X]+ years driving [core outcome] across [domain/industry].
Known for [primary differentiator]. Proven record of [quantified result]. [Credential or
domain credibility signal].
```

### Core Competencies

2–3 columns, 12–18 items. Top-left position = highest priority JD keyword. Include all
Tier 1 and top Tier 2 keywords. This section is keyword-density territory — make it count.

---

## STEP 5: COVER LETTER

**Constraint:** Max 450 words.

### Structure

**Opening:** Value proposition — lead with specific fit, not generic enthusiasm. Name the
role, name the fit, move immediately into substance.

**Body Paragraph 1:** Primary qualification + quantified achievement that directly addresses
the role's wound. This is your strongest proof point.

**Body Paragraph 2:** Cross-domain strength that directly serves this role — the thing another
candidate can't claim. What does the breadth of your background make possible here that a
straight-line candidate can't offer?

**Body Paragraph 3:** Contextual investment — why this organization, this mission, this moment.
Be specific. Generic enthusiasm reads as no research.

**Closing:** Availability and clear next step. No hedging.

### Cover Letter Guardrails

- No clichés ("I am writing to express my interest in...")
- No apologies for the career arc
- No over-explaining pivots
- No passive constructions in the opening paragraph
- No generic closing ("I look forward to hearing from you")

---

## STEP 6: EMPLOYMENT HISTORY & DATES

### Date Format Rule

**Always use:** `Month YYYY – Month YYYY` (e.g., `March 2019 – November 2023`)
**Never use:** Year-only ranges, "Present" without context, ambiguous formats

### Gap Prevention

No unexplained gaps > 2 months visible on page. Bridge language options:
- "Independent Contractor"
- "Freelance Consultant"
- "Career Transition / Professional Development"
- "Family Medical Leave"
- "Volunteer Leadership" (if accurate and substantial)

### Non-Linear History

Do not explain pivots inside bullet content. Use role titles and summary framing to carry
that weight. Parallel or overlapping contract/field work can be presented concurrently with
clear labels (Contract, Consulting, Interim) — only if accurate.

---

## STEP 7: TECHNICAL STANDARDS

- **File Type:** .docx — standard headers, no tables/text boxes/columns except Competencies
- **Font:** Arial (or equivalent clean sans-serif — Calibri, Helvetica acceptable)
- **The Fold Rule:** Top 1/3 of Page 1 must contain: Name, Role Title Matching JD, Core
  Value Prop, 2+ major metrics or credentials
- **Length:** 1.75 pages maximum, approximately 17–20 bullets total
- **Character limit:** ~7,500 total
- **Language:** Minimize passive voice (< 5%). Include both acronyms and spelled-out terms
  on first use.

---

## STEP 8: FINAL QA CHECKLIST

Run this before delivering any document.

- [ ] **Character Audit:** 100% of bullets ≤ 160 characters
- [ ] **Keyword Density:** 100% of Tier 1 keywords present
- [ ] **Metric Density:** Minimum 3 metrics per role (scale, outcome, or timeline)
- [ ] **Date Audit:** All dates include Month YYYY; no unexplained gaps > 2 months
- [ ] **Three-Question Test:** Every bullet passes SO WHAT / COMPARED TO WHAT / WHO CARES
- [ ] **Track Alignment:** Summary, competencies, and bullets all speak to the same role —
      no track bleed
- [ ] **Fold Rule verified:** Credentials and value prop visible in top third of page 1
- [ ] **Non-linear history framed, not explained**
- [ ] **Cover letter ≤ 450 words**
- [ ] **No clichés, no passive openings, no apologies for the arc**

---

## STEP 9: DELIVERY

Deliver three things:

**1. Resume & Cover Letter**
.docx format, ATS-friendly. One file each.

**2. ATS Compliance Report**
```
ATS COMPLIANCE REPORT
=====================
Character Count Audit:
  Bullets exceeding 160 chars: [count] / [total]
  Violations: [list if any]

Keyword Coverage:
  Tier 1 present: [X] / [X]
  Missing: [list if any]

Date Continuity:
  Gaps flagged: [list if any]

Metric Density:
  Roles with 3+ metrics: [X] / [X]
  Thin roles: [list if any]

Overall: [PASS / NEEDS REVISION]
```

**3. Quick Reference Card**
3 high-stakes talking points for the interview, drawn from the strongest cross-domain
differentiators. These are the things that don't fully fit in a bullet but matter in the room.

---

## CROSS-DOMAIN POSITIONING

The non-linear career is a story to tell selectively. This table shows how to translate
experience across contexts. Adapt to the person's actual history.

| Experience Type | Transformation / Operations Application | Mission-Driven Application |
|---|---|---|
| Crisis or emergency response | High-stakes execution under pressure, compliance under constraint | Multi-stakeholder coordination, public trust, mission-critical delivery |
| Teaching / training / facilitation | Knowledge transfer at scale, adoption strategy, capability building | Community engagement, accessible communication, train-the-trainer systems |
| Volunteer leadership | Mobilizing without authority, culture-building, sustaining without budget | Grassroots credibility, values alignment, earned trust |
| Entrepreneurship / freelance | Ownership mentality, end-to-end accountability, resource constraint | Founder-mindset in service of mission, scrappy delivery |
| Caregiving / life transitions | Prioritization under constraint, invisible project management | Human-centered perspective, lived experience of systems |
| Military | Operational precision, team leadership, mission-driven execution | Structure in service of values, high-accountability culture |
| Cross-sector moves | Breadth as depth — pattern recognition across contexts | Systems thinker who sees beyond the silo |

**The adjacency test:** For every cross-domain experience, ask:
*"What does this prove about how I operate — and does that proof matter for this role?"*
If yes, it belongs. Frame it that way, not as an explanation.

---

## ACTION VERB BANKS

### Transformation / Change Management
Architected, Transformed, Restructured, Institutionalized, Operationalized, Embedded,
Sustained, Accelerated, Realigned, Modernized

### Program / Project / Operations
Orchestrated, Spearheaded, Formalized, Governed, Owned, Drove, Instituted, Rationalized,
Delivered, Coordinated

### People / Culture / Leadership
Mobilized, Galvanized, Championed, Developed, Scaled, Built, Aligned, Mentored,
Established, Cultivated

### Technical / Digital / Security
Migrated, Integrated, Secured, Deployed, Hardened, Automated, Rationalized, Configured,
Implemented, Audited

### Social Impact / Nonprofit / Crisis
Mobilized, Restored, Championed, Sustained, Navigated, Coordinated, Served,
Institutionalized, Scaled, Established

### Avoid as primary verbs (across all tracks)
Facilitated, Led, Managed, Helped, Supported, Assisted, Worked on, Participated in

---

## THE THREE-QUESTION TEST

Every bullet must pass all three before it is final.

**SO WHAT**
What was the consequence of this action? What changed because it happened?
*Weak:* "Improved team communication."
*Strong:* "Reduced decision cycle from 3 weeks to 4 days."

**COMPARED TO WHAT**
What's the baseline this beat? What was true before?
*Weak:* "Achieved 95% stakeholder satisfaction."
*Strong:* "Achieved 95% stakeholder satisfaction vs. 71% prior-year baseline."

**WHO CARES**
Which stakeholder does this matter to, and why?
*Weak:* "Streamlined reporting process."
*Strong:* "Built executive dashboard eliminating 6hrs/week of manual reporting for VP-level
leaders."

If a bullet can't answer all three, it needs to be rebuilt — not polished.

---

*LiminalLiving.ResumeWork*
*© Liminal Living | CC BY-NC 4.0 | [liminalliving.net](https://liminalliving.net)*
*Free to use and adapt with attribution. Not for commercial use without permission.*
